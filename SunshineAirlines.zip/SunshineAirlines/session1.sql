/*
Navicat MySQL Data Transfer

Source Server         : 1
Source Server Version : 50515
Source Host           : localhost:3306
Source Database       : session1

Target Server Type    : MYSQL
Target Server Version : 50515
File Encoding         : 65001

Date: 2025-05-20 12:47:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `order`
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '订单编号',
  `user_id` int(10) unsigned NOT NULL COMMENT '用户ID（外键）',
  `order_time` date NOT NULL COMMENT '下单时间',
  `order_status` varchar(20) NOT NULL COMMENT '订单状态',
  `payment_status` varchar(20) NOT NULL COMMENT '支付状态',
  `payment_time` date DEFAULT NULL COMMENT '支付时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`order_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_order_time` (`order_time`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='订单主表';

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES ('1', '1', '2025-05-16', '待下单', '支付失败', '2025-05-09', '2025-05-16 19:32:11');

-- ----------------------------
-- Table structure for `product`
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `product_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品编号',
  `product_name` varchar(255) NOT NULL COMMENT '商品名称',
  `category` varchar(50) NOT NULL COMMENT '商品分类',
  `price` int(11) NOT NULL COMMENT '价格',
  `stock` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '库存量',
  `description` text COMMENT '商品描述',
  `create_time` datetime NOT NULL DEFAULT '2000-01-01 00:00:00' COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT '2000-01-01 00:00:00' COMMENT '更新时间',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('5', '手机', '电子', '50', '0', '用的', '2025-05-15 15:27:42', '2025-05-15 15:27:42');
INSERT INTO `product` VALUES ('6', 'sj', 'dz', '50', '50', 'sj', '2025-05-16 19:37:24', '2025-05-16 19:37:24');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `email` varchar(100) NOT NULL COMMENT '邮箱',
  `phone` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `address` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='用户信息表';

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '张三', 'zhangsan@example.com', '13800138000', '2025-05-10 15:55:12', '崇阳');
INSERT INTO `user` VALUES ('2', '李四', 'lisi@example.com', '13800138000', '2024-03-01 10:00:00', '上海市浦东新区');
DROP TRIGGER IF EXISTS `set_product_timestamps`;
DELIMITER ;;
CREATE TRIGGER `set_product_timestamps` BEFORE INSERT ON `product` FOR EACH ROW BEGIN
  -- 插入时自动填充 create_time 和 update_time
  SET NEW.create_time = NOW();
  SET NEW.update_time = NOW();
END
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `update_product_timestamp`;
DELIMITER ;;
CREATE TRIGGER `update_product_timestamp` BEFORE UPDATE ON `product` FOR EACH ROW BEGIN
  -- 更新时自动刷新 update_time
  SET NEW.update_time = NOW();
END
;;
DELIMITER ;
