// UserServlet.java
package edu.wtbu.servlet;

import java.io.IOException;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import edu.wtbu.pojo.Result;
import edu.wtbu.service.UserService;

@WebServlet("/user")
public class UserServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        Result result = null;
        
        try {
            switch(action) {
                case "list":
                    result = handleList(request);
                    break;
                case "add":
                    result = handleAdd(request);
                    break;
                case "update":
                    result = handleUpdate(request);
                    break;
                case "delete":
                    result = handleDelete(request);
                    break;
                case "detail":
                    result = handleDetail(request);
                    break;
                default:
                    result = new Result("fail", null, "无效操作");
            }
        } catch (Exception e) {
            result = new Result("error", null, "系统异常");
        }
        
        response.getWriter().append(JSON.toJSONString(result));
    }

    private Result handleList(HttpServletRequest request) {
        String keyword = request.getParameter("keyword") != null ? request.getParameter("keyword") : "";
        int startPage = parseInt(request.getParameter("startPage"), 1);
        int pageSize = parseInt(request.getParameter("pageSize"), 10);
        return UserService.userList(keyword, startPage, pageSize);
    }

    private Result handleAdd(HttpServletRequest request) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("username", request.getParameter("username"));
        map.put("email", request.getParameter("email"));
        map.put("phone", request.getParameter("phone"));
        map.put("address", request.getParameter("address"));
        return UserService.addUser(map);
    }

    private Result handleUpdate(HttpServletRequest request) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("userId", parseInt(request.getParameter("userId"), 0));
        map.put("username", request.getParameter("username"));
        map.put("email", request.getParameter("email"));
        map.put("phone", request.getParameter("phone"));
        map.put("address", request.getParameter("address"));
        return UserService.updateUser(map);
    }

    private Result handleDelete(HttpServletRequest request) {
        int userId = parseInt(request.getParameter("userId"), 0);
        return UserService.deleteUser(userId);
    }

    private Result handleDetail(HttpServletRequest request) {
        int userId = parseInt(request.getParameter("userId"), 0);
        return UserService.getUserDetail(userId);
    }

    private int parseInt(String value, int defaultValue) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doPost(request, response);
    }
}