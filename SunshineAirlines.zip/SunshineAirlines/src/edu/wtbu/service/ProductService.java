// ProductService.java
package edu.wtbu.service;

import java.util.HashMap;
import java.util.List;

import edu.wtbu.dao.ProductDao;
import edu.wtbu.pojo.Page;
import edu.wtbu.pojo.Result;

public class ProductService {
    
    // 商品列表查询（带分页）
    public static Result productList(String name, int startPage, int pageSize) {
        List<HashMap<String, Object>> list = ProductDao.findProductListByPage(name, startPage, pageSize);
        int total = ProductDao.findProductCount(name);
        Page page = new Page(total, startPage, pageSize);
        return new Result("success", page, list);
    }
    
    // 添加商品
    public static Result addProduct(HashMap<String, Object> map) {
        Result result = new Result("fail", null, "添加失败");
        
        // 参数校验
        if(map.get("productName") == null || map.get("productName").toString().isEmpty()) {
            result.setData("商品名称不能为空");
            return result;
        }
        
        if(ProductDao.addProduct(map) > 0) {
            result.setFlag("success");
            result.setData("添加成功");
        }
        return result;
    }
    
    // 更新商品
    public static Result updateProduct(HashMap<String, Object> map) {
        Result result = new Result("fail", null, "更新失败");
        int productId = Integer.parseInt(map.get("productId").toString());
        
        // 校验商品是否存在
        if(ProductDao.findByProductId(productId) == null) {
            result.setData("商品不存在");
            return result;
        }
        
        if(ProductDao.updateProduct(map) > 0) {
            result.setFlag("success");
            result.setData("更新成功");
        }
        return result;
    }
    
    // 删除商品
    public static Result deleteProduct(int productId) {
        Result result = new Result("fail", null, "删除失败");
        if(ProductDao.deleteProduct(productId) > 0) {
            result.setFlag("success");
            result.setData("删除成功");
        }
        return result;
    }
    
    // 获取商品详情
    public static Result getProductDetail(int productId) {
        Result result = new Result("fail", null, "商品不存在");
        HashMap<String, Object> product = ProductDao.findByProductId(productId);
        if(product != null) {
            result.setFlag("success");
            result.setData(product);
        }
        return result;
    }
}