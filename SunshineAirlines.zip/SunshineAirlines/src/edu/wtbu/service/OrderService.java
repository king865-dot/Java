// OrderService.java
package edu.wtbu.service;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.dao.OrderDao;
import edu.wtbu.pojo.Page;
import edu.wtbu.pojo.Result;

public class OrderService {
    
    // 订单列表查询（带分页）
    public static Result orderList(String orderId, int startPage, int pageSize) {
        List<HashMap<String, Object>> list = OrderDao.findOrderListByPage(orderId, startPage, pageSize);
        int total = OrderDao.findOrderCount(orderId);
        Page page = new Page(total, startPage, pageSize);
        return new Result("success", page, list);
    }
    
    // 添加订单
    public static Result addOrder(HashMap<String, Object> map) {
        Result result = new Result("fail", null, "添加失败");
        
        if(OrderDao.addOrder(map) > 0) {
            result.setFlag("success");
            result.setData("添加成功");
        }
        return result;
    }
    
    // 更新订单状态
    public static Result updateOrderStatus(HashMap<String, Object> map) {
        Result result = new Result("fail", null, "更新失败");
        int orderId = Integer.parseInt(map.get("orderId").toString());
        
        if(OrderDao.findByOrderId(orderId) == null) {
            result.setData("订单不存在");
            return result;
        }
        
        if(OrderDao.updateOrderStatus(map) > 0) {
            result.setFlag("success");
            result.setData("更新成功");
        }
        return result;
    }
    
    // 删除订单
    public static Result deleteOrder(int orderId) {
        Result result = new Result("fail", null, "删除失败");
        if(OrderDao.deleteOrder(orderId) > 0) {
            result.setFlag("success");
            result.setData("删除成功");
        }
        return result;
    }
    
    // 获取订单详情
    public static Result getOrderDetail(int orderId) {
        Result result = new Result("fail", null, "订单不存在");
        HashMap<String, Object> order = OrderDao.findByOrderId(orderId);
        if(order != null) {
            result.setFlag("success");
            result.setData(order);
        }
        return result;
    }
}