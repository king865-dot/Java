// UserService.java
package edu.wtbu.service;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.dao.UserDao;
import edu.wtbu.pojo.Page;
import edu.wtbu.pojo.Result;

public class UserService {
    
    // 用户列表查询（带分页）
    public static Result userList(String keyword, int startPage, int pageSize) {
        List<HashMap<String, Object>> list = UserDao.findUserListByPage(keyword, startPage, pageSize);
        int total = UserDao.findUserCount(keyword);
        Page page = new Page(total, startPage, pageSize);
        return new Result("success", page, list);
    }
    
    // 添加用户
    public static Result addUser(HashMap<String, Object> map) {
        Result result = new Result("fail", null, "添加失败");
        
        // 参数校验
        if(map.get("username") == null || map.get("username").toString().isEmpty()) {
            result.setData("用户名不能为空");
            return result;
        }
        
        if(map.get("email") == null || map.get("email").toString().isEmpty()) {
            result.setData("邮箱不能为空");
            return result;
        }
        
        if(UserDao.isEmailExists(map.get("email").toString())) {
            result.setData("邮箱已被注册");
            return result;
        }
        
        if(UserDao.addUser(map) > 0) {
            result.setFlag("success");
            result.setData("添加成功");
        }
        return result;
    }
    
    // 更新用户信息
    public static Result updateUser(HashMap<String, Object> map) {
        Result result = new Result("fail", null, "更新失败");
        int userId = Integer.parseInt(map.get("userId").toString());
        
        // 校验用户是否存在
        if(UserDao.findByUserId(userId) == null) {
            result.setData("用户不存在");
            return result;
        }
        
        // 检查邮箱冲突
        String newEmail = map.get("email").toString();
        HashMap<String, Object> oldUser = UserDao.findByUserId(userId);
        if(!newEmail.equals(oldUser.get("email")) && UserDao.isEmailExists(newEmail)) {
            result.setData("邮箱已被其他用户使用");
            return result;
        }
        
        if(UserDao.updateUser(map) > 0) {
            result.setFlag("success");
            result.setData("更新成功");
        }
        return result;
    }
    
    // 删除用户
    public static Result deleteUser(int userId) {
        Result result = new Result("fail", null, "删除失败");
        if(UserDao.deleteUser(userId) > 0) {
            result.setFlag("success");
            result.setData("删除成功");
        }
        return result;
    }
    
    // 获取用户详情
    public static Result getUserDetail(int userId) {
        Result result = new Result("fail", null, "用户不存在");
        HashMap<String, Object> user = UserDao.findByUserId(userId);
        if(user != null) {
            result.setFlag("success");
            result.setData(user);
        }
        return result;
    }
}