// OrderDao.java
package edu.wtbu.dao;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.helper.MySqlHelper;

public class OrderDao {
    
    // 分页查询订单列表
    public static List<HashMap<String, Object>> findOrderListByPage(String orderId, int startPage, int pageSize) {
        String sql = "SELECT o.*, u.username FROM `order` o "
                   + "JOIN user u ON o.user_id = u.user_id "
                   + "WHERE o.order_id LIKE ? "
                   + "ORDER BY o.order_id ASC LIMIT ?,?";
        return MySqlHelper.executeQueryReturnMap(sql, 
                new Object[] { "%" + orderId + "%", (startPage-1) * pageSize, pageSize });
    }
    
    // 获取订单总数
    public static int findOrderCount(String orderId) {
        String sql = "SELECT COUNT(1) AS Total FROM `order` WHERE order_id LIKE ?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql,
                new Object[] { "%" + orderId + "%" });
        return (list != null && !list.isEmpty()) ? Integer.parseInt(list.get(0).get("Total").toString()) : 0;
    }
    
    // 添加新订单
    public static int addOrder(HashMap<String, Object> map) {
        String sql = "INSERT INTO `order` (user_id, order_time, order_status, payment_status) "
                   + "VALUES(?,?,?,?)";
        return MySqlHelper.executeUpdate(sql,
                new Object[] { 
                    map.get("userId"),
                    map.get("orderTime"),
                    map.get("orderStatus"),
                    map.get("paymentStatus")
                });
    }
    
    // 更新订单状态
    public static int updateOrderStatus(HashMap<String, Object> map) {
        String sql = "UPDATE `order` SET order_status=?, payment_status=?, payment_time=? "
                   + "WHERE order_id=?";
        return MySqlHelper.executeUpdate(sql,
                new Object[] { 
                    map.get("orderStatus"),
                    map.get("paymentStatus"),
                    map.get("paymentTime"),
                    map.get("orderId")
                });
    }
    
    // 删除订单
    public static int deleteOrder(int orderId) {
        String sql = "DELETE FROM `order` WHERE order_id=?";
        return MySqlHelper.executeUpdate(sql, new Object[] { orderId });
    }
    
    // 根据ID查询订单详情
    public static HashMap<String, Object> findByOrderId(int orderId) {
        String sql = "SELECT o.*, u.username FROM `order` o "
                   + "JOIN user u ON o.user_id = u.user_id "
                   + "WHERE o.order_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, new Object[] { orderId });
        return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
}