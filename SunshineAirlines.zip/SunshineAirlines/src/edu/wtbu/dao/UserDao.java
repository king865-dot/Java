// UserDao.java
package edu.wtbu.dao;

import java.util.HashMap;
import java.util.List;
import edu.wtbu.helper.MySqlHelper;

public class UserDao {
    
    // 分页查询用户列表
    public static List<HashMap<String, Object>> findUserListByPage(String keyword, int startPage, int pageSize) {
        String sql = "SELECT * FROM user WHERE username LIKE ? OR email LIKE ? OR phone LIKE ? "
                   + "ORDER BY user_id ASC LIMIT ?,?";
        return MySqlHelper.executeQueryReturnMap(sql, 
                new Object[] { 
                    "%" + keyword + "%", 
                    "%" + keyword + "%",
                    "%" + keyword + "%",
                    (startPage-1) * pageSize, 
                    pageSize 
                });
    }
    
    // 获取用户总数
    public static int findUserCount(String keyword) {
        String sql = "SELECT COUNT(1) AS Total FROM user "
                   + "WHERE username LIKE ? OR email LIKE ? OR phone LIKE ?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql,
                new Object[] { "%" + keyword + "%", "%" + keyword + "%", "%" + keyword + "%" });
        return (list != null && !list.isEmpty()) ? Integer.parseInt(list.get(0).get("Total").toString()) : 0;
    }
    
    // 添加新用户
    public static int addUser(HashMap<String, Object> map) {
        String sql = "INSERT INTO user (username, email, phone, address) VALUES(?,?,?,?)";
        return MySqlHelper.executeUpdate(sql,
                new Object[] { 
                    map.get("username"),
                    map.get("email"),
                    map.get("phone"),
                    map.get("address")
                });
    }
    
    // 更新用户信息
    public static int updateUser(HashMap<String, Object> map) {
        String sql = "UPDATE user SET username=?, email=?, phone=?, address=? WHERE user_id=?";
        return MySqlHelper.executeUpdate(sql,
                new Object[] { 
                    map.get("username"),
                    map.get("email"),
                    map.get("phone"),
                    map.get("address"),
                    map.get("userId")
                });
    }
    
    // 删除用户
    public static int deleteUser(int userId) {
        String sql = "DELETE FROM user WHERE user_id=?";
        return MySqlHelper.executeUpdate(sql, new Object[] { userId });
    }
    
    // 根据ID查询用户详情
    public static HashMap<String, Object> findByUserId(int userId) {
        String sql = "SELECT * FROM user WHERE user_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, new Object[] { userId });
        return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
    
    // 检查邮箱是否已存在
    public static boolean isEmailExists(String email) {
        String sql = "SELECT COUNT(1) AS cnt FROM user WHERE email=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, new Object[] { email });
        return list != null && !list.isEmpty() && Integer.parseInt(list.get(0).get("cnt").toString()) > 0;
    }
}