package edu.wtbu.dao;

import java.util.HashMap;
import java.util.List;

import edu.wtbu.helper.MySqlHelper;

public class ProductDao {
    
    // 分页查询商品列表
    public static List<HashMap<String, Object>> findProductListByPage(String name, int startPage, int pageSize) {
        String sql = "SELECT * FROM product WHERE product_name LIKE ? ORDER BY product_id ASC LIMIT ?,?";
        return MySqlHelper.executeQueryReturnMap(sql, 
                new Object[] { "%" + name + "%", (startPage-1) * pageSize, pageSize });
    }
    
    // 获取商品总数
    public static int findProductCount(String name) {
        String sql = "SELECT COUNT(1) AS Total FROM product WHERE product_name LIKE ?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql,
                new Object[] { "%" + name + "%" });
        return (list != null && !list.isEmpty()) ? Integer.parseInt(list.get(0).get("Total").toString()) : 0;
    }
    
    // 添加新商品
    public static int addProduct(HashMap<String, Object> map) {
        String sql = "INSERT INTO product (product_name, category, price, stock, description) "
                   + "VALUES(?,?,?,?,?)";
        return MySqlHelper.executeUpdate(sql,
                new Object[] { 
                    map.get("productName"), 
                    map.get("category"),
                    map.get("price"),
                    map.get("stock"),
                    map.get("description") 
                });
    }
    
    // 更新商品信息
    public static int updateProduct(HashMap<String, Object> map) {
        String sql = "UPDATE product SET product_name=?, category=?, price=?, stock=?, description=? "
                   + "WHERE product_id=?";
        return MySqlHelper.executeUpdate(sql,
                new Object[] { 
                    map.get("productName"),
                    map.get("category"),
                    map.get("price"),
                    map.get("stock"),
                    map.get("description"),
                    map.get("productId")
                });
    }
    
    // 删除商品
    public static int deleteProduct(int productId) {
        String sql = "DELETE FROM product WHERE product_id=?";
        return MySqlHelper.executeUpdate(sql, new Object[] { productId });
    }
    
    // 根据ID查询商品详情
    public static HashMap<String, Object> findByProductId(int productId) {
        String sql = "SELECT * FROM product WHERE product_id=?";
        List<HashMap<String, Object>> list = MySqlHelper.executeQueryReturnMap(sql, new Object[] { productId });
        return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
}


